# SRP Approved Asset Filenames

Replace the placeholder JPG files with the final approved exported/cropped images using the exact same filenames.

- assets/hero-composite.jpg: APPROVED 1A HERO COMPOSITE
- assets/grand-jete.jpg: APPROVED 1B GRAND JETÉ
- assets/dance-editorial.jpg: APPROVED 2A DANCE EDITORIAL
- assets/pointe-closeup.jpg: APPROVED 2B POINTE CLOSE-UP
- assets/dance-jete-smoke.jpg: APPROVED 2C GRAND JETÉ
- assets/sprint-start.jpg: APPROVED 3A SPRINT START
- assets/sled-push.jpg: APPROVED 3B SLED PUSH
- assets/med-ball-slam.jpg: APPROVED 3C MED BALL SLAM
- assets/kettlebell-coaching.jpg: APPROVED 4A KETTLEBELL COACHING
- assets/bench-coaching.jpg: APPROVED 4B BENCH PRESS COACHING
- assets/high-plank.jpg: APPROVED 4C HIGH PLANK
- assets/research-notebook.jpg: APPROVED 5A RESEARCH NOTEBOOK
- assets/srp-orbital.jpg: APPROVED 5C SRP ORBITAL LOGO
- assets/linework-sprinter.jpg: APPROVED 6A MALE SPRINTER LINEWORK
- assets/linework-ballet.jpg: APPROVED 6B BALLET LINEWORK
- assets/linework-broad-jump.jpg: APPROVED 6C BROAD JUMP LINEWORK
- assets/service-dance.jpg: APPROVED 7A SERVICE DANCE
- assets/service-team.jpg: APPROVED 7B COLLEGIATE TEAM TRAINING
- assets/service-online.jpg: APPROVED 7C ONLINE PROGRAMMING
- assets/service-personal.jpg: APPROVED 7D PERSONAL TRAINING

Do not rename files unless you also update the HTML references.
